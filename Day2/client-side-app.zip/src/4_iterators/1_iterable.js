class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    [Symbol.iterator]() {
        let i = 0;
        const self = this;

        return {
            next: function () {
                let v, d = true;

                if (self._dataArray[i] !== undefined) {
                    v = self._dataArray[i];
                    d = false;
                    i += 1;
                }

                return {
                    value: v,
                    done: d
                };
            }
        };
    }
}

let numbersQ = new Queue();
numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);

// console.log(numbersQ.pop());
// console.log(numbersQ.pop());
// console.log(numbersQ.pop());

for (const n of numbersQ) {
    console.log(n);
}

// const it = numbersQ[Symbol.iterator]();

// console.log(it.next());
// console.log(it.next());
// console.log(it.next());
// console.log(it.next());