// function hello() {
//     console.log("Hello World!");
// }

// hello();

// IIFE - Immediatly Invoked Function Expression

(function () {
    console.log("Hello World!");
})();

(() => {
    console.log("Arrow - Hello World!");
})();
