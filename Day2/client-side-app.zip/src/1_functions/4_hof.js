// function add(x, y) {
//     return x + y;
// }

// function sub(x, y) {
//     return x - y;
// }

// // I want to log the arguments passed to the add and sub function

// console.log(add(2, 3));
// console.log(sub(20, 3));

// --------------------------------------------

// function add(x, y) {
//     console.log(`add called with args, ${x}, ${y}`);
//     return x + y;
// }

// function sub(x, y) {
//     console.log(`sub called with args, ${x}, ${y}`);
//     return x - y;
// }

// // I want to log the arguments passed to the add and sub function

// console.log(add(2, 3));
// console.log(sub(20, 3));

// -----------------------------------------------

// function add(x, y) {
//     log(add, x, y);
//     return x + y;
// }

// function sub(x, y) {
//     log(sub, x, y);
//     return x - y;
// }


// function log(fn, ...args) {
//     console.log(`${fn.name} called with arguments, ${args}`);
// }
// // I want to log the arguments passed to the add and sub function

// console.log(add(2, 3));
// console.log(sub(20, 3));

// -----------------------------------------------

// function add(x, y) {
//     return x + y;
// }

// function sub(x, y) {
//     return x - y;
// }

// function logDecorator(fn) {
//     return function (...args) {
//         console.log(`${fn.name} called with arguments, ${args}`);
//         let result = fn(...args);
//         return result;
//     }
// }

// const addWithLogging = logDecorator(add);
// const subWithLogging = logDecorator(sub);

// console.log(addWithLogging(2, 3));
// console.log(subWithLogging(20, 3));

// ------------------------------------------------------

function m1(x, y) {
    throw Error("Invalid Arguments....");
}

function m2(x, y) {
    throw Error("Wrong Arguments....");
}

// try {
//     m1(20, 30);
// } catch (e) {
//     console.error(e.message);
// }

// try {
//     m2(20, 30);
// } catch (e) {
//     console.error(e.message);
// }

// Create a Higher Order Function to handle exceptions

function errorHandlerDecorator(fn) {
    return function (...args) {
        try {
            let result = fn(...args);
            return result;
        } catch (e) {
            console.error(e.message);
        }
    }
}

errorHandlerDecorator(m1)(20,30);
errorHandlerDecorator(m2)(20,30);