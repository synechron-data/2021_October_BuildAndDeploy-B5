/* eslint-disable */
import React, { Component } from 'react';

class CalculatorOne extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="justify-content-center">
                        <fieldset>
                            <legend className="text-center">Calculator One</legend>
                            <div className="form-group mb-1">
                                <label className="mb-0" htmlFor="t1">Number One</label>
                                <input type="text" className="form-control" id="t1" />
                            </div>
                            <div className="form-group mb-1">
                                <label className="mb-0" htmlFor="t2">Number Two</label>
                                <input type="text" className="form-control" id="t2" />
                            </div>
                            <div className="form-group">
                                <h3>Result: </h3>
                            </div>
                            <div className="form-group">
                                <button type="submit" className="btn btn-success btn-block">Add</button>
                                <button type="reset" className="btn btn-primary btn-block">Reset</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

const CalculatorAssignment = () => {
    return (
        <div>
            <CalculatorOne />
        </div>
    );
};

export default CalculatorAssignment;