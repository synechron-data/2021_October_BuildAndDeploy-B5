import React, { useContext } from 'react';
import { CounterContext, CounterContextProvider } from '../../context/CounterContextUsingHook';

const Counter = (props) => {
    const [count, setCount] = useContext(CounterContext);

    return (
        <React.Fragment>
            <div className="text-center">
                <h3 className="text-info">Counter Component</h3>
            </div>
            <div className="row d-flex justify-content-center">
                <div className="col-sm-4">
                    <input type="text" className="form-control" value={count} readOnly />
                </div>
                <div className="col-sm-1">
                    <button className="btn btn-info btn-block" onClick={() => setCount(count + props.interval)}>+</button>
                </div>
                <div className="col-sm-1">
                    <button className="btn btn-info btn-block" onClick={() => setCount(count - props.interval)}>-</button>
                </div>
            </div>
        </React.Fragment>
    );
}

Counter.defaultProps = {
    interval: 1
};

const CounterSibling = () => {
    const [count] = useContext(CounterContext);

    return (
        <>
            <div className="text-center">
                <h3 className="text-info">Counter Sibling Component</h3>
                <h3>Current Count is: {count}</h3>
            </div>
        </>
    );
}

const SiblingCommunicationUsingHooks = () => {
    return (
        <div>
            <CounterContextProvider>
                <Counter />
                <hr />
                <CounterSibling />
            </CounterContextProvider>
        </div>
    );
};

export default SiblingCommunicationUsingHooks;