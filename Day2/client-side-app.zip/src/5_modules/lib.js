// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// Case 2 - Named Exports - Multiple Exports
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked: ${x}`;
// }

// function test(x) {
//     return `Tested: ${x}`;
// }

// Only one default export allowed per module.
// Case 3 - Default and Named Exports 
// export default function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked: ${x}`;
// }

// Create and Export Person Class from this file

// class Person {
//     constructor(name) {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     setName(value) {
//         this._name = value;
//     }
// }

// export default Person;

export default class Person {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(value) {
        this._name = value;
    }
}