import { Component } from "react"

const ClockHOC = (InputComponent) => class extends Component {
    static get displayName() {
        return "ClockHOC";
    }

    constructor(props) {
        super(props);
        this.state = { currentTime: new Date().toLocaleTimeString() };
    }

    componentDidMount() {
        setInterval(() => {
            this.setState({ currentTime: new Date().toLocaleTimeString() });
        }, 1000);
    }

    render() {
        return (
            <>
                <div className="lead text-right font-weight-bold text-primary">
                    {this.state.currentTime}
                </div>
                <InputComponent  {...this.props} />
            </>
        );
    }
}

export default ClockHOC;