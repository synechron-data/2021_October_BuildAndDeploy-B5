// Import an entire module for side effects only, without importing anything.
// This will run the module's global code, but doesn't import any values.

// import './1_datatypes/1_declarations';
// import './1_datatypes/2_es6_declarations';
// import './1_datatypes/3_es6_const';
// import './1_datatypes/4_datatypes';
// import './1_datatypes/5_symbol';

// import './2_functions/1_fn_creation';
// import './2_functions/2_iife';
// import './2_functions/3_fn_parameters';
// import './2_functions/4_rest_and_spread';
import './2_functions/5_closure';
