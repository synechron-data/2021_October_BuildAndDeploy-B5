class Person {
    constructor(name, pin) {
        this._name = name;
        this._pin = pin;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }

    get Pin() {
        return this._pin;
    }

    set Pin(value) {
        this._pin = value;
    }
}

var p1 = new Person("Manish", 411021);
console.log(p1.Name);       // get
console.log(p1.Pin);
p1.Name = "Abhijeet";       // set
p1.Pin = 411038;
console.log(p1.Name);
console.log(p1.Pin);
