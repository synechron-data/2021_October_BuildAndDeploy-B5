// Import an entire module for side effects only, without importing anything.
// This will run the module's global code, but doesn't import any values.

// import './1_functions/1_pure_impure_fn';
// import './1_functions/2_context';
// import './1_functions/3_fn_currying';
// import './1_functions/4_hof';

// import './2_objects/1_object_creation';
// import './2_objects/2_object_type';
// import './2_objects/3_custom_types';
// import './2_objects/4_using_prototype';
// import './2_objects/5_es6_class';
// import './2_objects/6_es6_property';
// import './2_objects/7_es6_static_members';
// import './2_objects/8_es6_inheritance';

// import './3_collections/1_arrays';
// import './3_collections/2_es6_map';
// import './3_collections/3_es6_set';

// import './4_iterators/1_iterable';
// import './4_iterators/2_generator';

// import './5_modules/usage';

// import './6_promise/1_creating_promise';
// import './6_promise/2_chaining_promise';
import './6_promise/3_promise_methods';


// import './7_ajax/domHandler';