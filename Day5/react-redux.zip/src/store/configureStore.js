// 1. Basic Configuration

// import { createStore } from "redux";
// import rootReducer from "../reducers/rootReducer";

// export default function configureStore(preloadedState) {
//     return createStore(
//         rootReducer,
//         preloadedState,
//         window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
//     );
// }

// 2. Custom Middleware
// import { createStore, applyMiddleware } from "redux";
// import rootReducer from "../reducers/rootReducer";

// const customMiddleware = store => next => action => {
//     console.log("Custom Middleware Executed: ", action);
//     next(action);
// }

// export default function configureStore(preloadedState) {
//     return createStore(
//         rootReducer,
//         preloadedState,
//         applyMiddleware(customMiddleware)
//     );
// }

// 3. Using the Thunk Middleware
// npm i redux-thunk
// import { createStore, applyMiddleware } from "redux";
// import thunk from 'redux-thunk';

// import rootReducer from "../reducers/rootReducer";

// export default function configureStore(preloadedState) {
//     return createStore(
//         rootReducer,
//         preloadedState,
//         applyMiddleware(thunk)
//     );
// }

// 4. Using the Thunk Middleware wuth Redux Devtools
// npm i redux-thunk
// npm i redux-devtools-extension

import { createStore, applyMiddleware } from "redux";
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';

import rootReducer from "../reducers/rootReducer";

export default function configureStore(preloadedState) {
    return createStore(
        rootReducer,
        preloadedState,
        composeWithDevTools(applyMiddleware(thunk))
    );
}