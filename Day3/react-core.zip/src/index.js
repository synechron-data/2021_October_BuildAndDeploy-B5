// // Application Level CSS / Global CSS
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import HelloComponent from './components/1_hello/HelloComponent';

// ReactDOM.render(
//   <React.StrictMode>
//     <HelloComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// // -------------------------------------------------- Using Bootstrap 4
// // npm i bootstrap@4 popper.js jquery
// // npm i -D node-sass

// // Application Level CSS / Global CSS
// import 'bootstrap/scss/bootstrap.scss';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import HelloComponent from './components/1_hello/HelloComponent';

// ReactDOM.render(
//   <React.StrictMode>
//     <HelloComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// -------------------------------------------------- Multi Components
// import 'bootstrap/scss/bootstrap.scss';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// // ReactDOM.render(
// //   <React.StrictMode>
// //     <ComponentOne />
// //   </React.StrictMode>,
// //   document.getElementById('root1')
// // );

// // ReactDOM.render(
// //   <React.StrictMode>
// //     <ComponentTwo />
// //   </React.StrictMode>,
// //   document.getElementById('root2')
// // );

// ReactDOM.render(
//   <React.StrictMode>
//     <ComponentOne />
//     <ComponentTwo />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// -------------------------------------------------- Using Root Component
import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import RootComponent from './components/root/RootComponent';

ReactDOM.render(
  <React.StrictMode>
    <RootComponent />
  </React.StrictMode>,
  document.getElementById('root')
);

// var person = { id: 1, name: "Manish", address: { state: "MH" } };

// Shallow Copy
// var p2 = {};
// p2.id = person.id;
// p2.name = person.name;
// p2.address = person.address;

// var p2 = Object.assign({}, person);
// var p2 = { ...person };

// Deep Copy
// var p2 = {};
// p2.id = person.id;
// p2.name = person.name;
// p2.address = {};
// p2.address.state = person.address.state;

// var p2 = JSON.parse(JSON.stringify(person));

// p2.id = 100;
// p2.address.state = "MP";

// console.log(person);
// console.log(p2);
