import React, { Component } from 'react';
import DataHOC from './DataHOC';

class HOCDemoComponentTwo extends Component {
    render() {
        return (
            <div>
                <div>
                    <h1 className="text-info">Higher Order Component Two Demo</h1>
                    <h2 className="text-success">Some Data, added by HOC: {this.props.data}</h2>
                </div>
            </div>
        );
    }
}

export default DataHOC(HOCDemoComponentTwo);

// const EnhancedComponent = DataHOC(HOCDemoComponentTwo);
// export default EnhancedComponent;

// export default HOCDemoComponentTwo;