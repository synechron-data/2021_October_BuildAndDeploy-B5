'use strict'

// var count = 0;

// function next() {
//     return count += 1;
// }

// setInterval(() => {
//     console.log(next());
// }, 2000);

// setTimeout(() => {
//     count = "abc";
// }, 5000);

// -------------------------------------------

// function next() {
//     var count = 0;
//     return count += 1;
// }

// setInterval(() => {
//     console.log(next());
// }, 2000);

// -------------------------------------------

// const next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// setInterval(() => {
//     console.log(next());
// }, 2000);

// -----------------------------------------------

// const counter = (function () {
//     var count = 0;

//     function next() {
//         return count += 1;
//     }

//     function prev() {
//         return count -= 1;
//     }

//     // return {
//     //     next: next,
//     //     prev: prev
//     // };

//     // ECMASCRIPT 2015 - Object Literal Improvement
//     return {
//         next, prev
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.prev());
// console.log(counter.prev());

// ------------------------------------------------------
function getCounter(by = 1) {
    var count = 0;
    var interval = by;

    function next() {
        return count += interval;
    }

    function prev() {
        return count -= interval;
    }

    return {
        next, prev
    };
}

const counter = getCounter();

console.log(counter.next());
console.log(counter.next());
console.log(counter.prev());
console.log(counter.prev());

console.log("\n");
const counter5 = getCounter(5);
console.log(counter5.next());
console.log(counter5.next());
console.log(counter5.prev());
console.log(counter5.prev());