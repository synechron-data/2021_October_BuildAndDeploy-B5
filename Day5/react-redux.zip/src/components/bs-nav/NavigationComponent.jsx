import React from 'react';
import { NavLink } from 'react-router-dom';

import SwitchComponent from '../../routes';

import './NavigationComponent.css';

var logo = require('../../logo.svg').default;

const NavigationComponent = () => {
    return (
        <>
            <nav className="navbar navbar-expand-sm bg-secondary navbar-dark fixed-top">
                <NavLink className="navbar-brand" to="/">
                    <img src={logo} className="d-inline-block align-top mr-1" alt="React Redux" height="30" width="30" />
                    React Redux
                </NavLink>
                <button className="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarText" aria-controls="navbarText"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarText">
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item px-3">
                            <NavLink exact className="nav-link" to="/">Home</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/about">About</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/hoc">HOC</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/hoc2">HOC Two</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/counter">Counter</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/products">Products</NavLink>
                        </li>
                    </ul>
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/signup">
                                SignUp
                            </NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link" to="/login">
                                Login
                            </NavLink>
                        </li>
                    </ul>
                </div>
            </nav>
            <>
                {SwitchComponent}
            </>
        </>
    );
};

export default NavigationComponent;