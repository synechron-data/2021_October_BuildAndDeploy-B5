/* eslint-disable */
import React from 'react';

import CalculatorAssignment from '../assignment/CalculatorAssignment';
import CounterAssignment from '../assignment/CounterAssignment';
import AjaxComponent from '../1_ajax/AjaxComponent';
import ErrorHandler from '../common/ErrorHandler';
import ContextAPIDemo from '../2_context-api/ContextAPIDemo';
import SiblingCommunicationUsingContext from '../2_context-api/SiblingCommunication';
import HooksDemoComponent from '../3_hooks/HooksDemoComponent';
import SiblingCommunicationUsingHooks from '../3_hooks/SiblingCommunicationUsingHooks';

const RootComponent = () => {
    return (
        <div className="container">
            <ErrorHandler>
                {/* <CalculatorAssignment /> */}
                {/* <CounterAssignment /> */}
                {/* <AjaxComponent /> */}
                {/* <ContextAPIDemo /> */}
                {/* <SiblingCommunicationUsingContext /> */}
                {/* <HooksDemoComponent /> */}
                <SiblingCommunicationUsingHooks />
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;